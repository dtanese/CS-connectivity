save_path =['./'];

close all
load('./CS demo dense FOV.mat')
CS_demo_fn(dense_fov)
datanames='CS demo dense FOV';
% saveas(gcf,[save_path datanames '.svg'])
% exportgraphics(gcf,[save_path datanames '.png'],'Resolution',600)
% savefig([save_path datanames '.fig'])

load('./CS demo sparse FOV.mat')
CS_demo_fn(sparse_fov)
datanames='CS demo sparse FOV';
% saveas(gcf,[save_path datanames '.svg'])
% exportgraphics(gcf,[save_path datanames '.png'],'Resolution',600)
% savefig([save_path datanames '.fig'])

%%
function CS_demo_fn(fov)
    nconnected=[];
    nconnected_m = fov.measurement_matrix * fov.sequential_connections;
    for i=1:length(nconnected_m)
        nconnected{i}=['# of connected cell: ' num2str(nconnected_m(i))];
    end
    reconstructed_responses = CS(fov.measurement_matrix,fov.multi_cell_stim_responses,0.1);
    [~,C,~] = kmeans(reconstructed_responses,2,'MaxIter',50,'Distance','sqeuclidean','Replicates',500);
    threshold = mean(C);
    trueLabels = fov.sequential_connections==1;
    predictedLabels = reconstructed_responses>threshold;
    cs_label=[];
    for i=1:fov.N
        if fov.sequential_connections(i)==0 & predictedLabels(i)==0
            cs_label{i}=['True negative'];
        elseif fov.sequential_connections(i)==0 & predictedLabels(i)==1
            cs_label{i}=['False positive'];
        elseif fov.sequential_connections(i)==1 & predictedLabels(i)==0
            cs_label{i}=['False negative'];
        elseif fov.sequential_connections(i)==1 & predictedLabels(i)==1
            cs_label{i}=['True positive'];
        end
    end
    figure('Position',[-1000,100,1000,300])
    sgtitle(fov.titles{1})
    subplot('Position', [0.1, 0.2, 0.2, 0.65]);
    h = gscatter(fov.measurement_matrix*fov.sequential_responses,fov.multi_cell_stim_responses,nconnected')
    xlabel({'Sum of responses to single-';'cell stim. (STA amp., pA)'})
    ylabel({'Response to multi-cell ';'stim. (STA amp., pA)'})
    title(fov.titles{2})
    xylim = max([xlim ylim])+1.5;
    xlim([-0.5,xylim]);ylim([-0.5,xylim])
    legend('location','northeast')
    subplot('Position', [0.42, 0.2, 0.2, 0.65]);
    gscatter(fov.sequential_responses,reconstructed_responses,cs_label')
    yline(threshold,'DisplayName','Threshold')
    xlabel({'Resp. to single-cell stim.';'(STA amp., pA)'})
    ylabel({'Reconstructed resp.';'(STA amp., pA)'})
    xylim = max([xlim ylim])+1.5;
    xlim([-0.5,xylim]);ylim([-0.5,xylim])
    title(fov.titles{3})
    legend('location','northeast')
    subplot('Position', [0.72, 0.2, 0.18, 0.6])
    confusionchart(trueLabels,predictedLabels,'Title','Confusion matrix');
end

function xp = CS(A,y,lambda)
[m, n] = size(A);
[m, t] = size(y);
cvx_begin quiet
    variable x(n,t);
    minimize(0.5*norm(A*x-y,2) + lambda*norm(x,1));
    subject to
        0  <=  x <= 40;
cvx_end
xp = x;
end